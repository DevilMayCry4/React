import logo from './logo.svg';
import './App.css';
import Input from './Input';
import { getInsights } from '@antv/ava';
import { InsightCard } from '@antv/ava-react';
import axios from 'axios'; 

let data = []
setData = null
 

function App() {
     const [data,setData] = useState();
  const getData = async () => {
    let result = await axios.get('/data.json');
    setData(result)
  }
  useEffect(() => {
     // Fetching Data on Initial Load
     getData()
  },[])
 

  return (
    <div className="root"> 
      <InsightCard insightInfo={data[0]} visualizationOptions={{ lang: 'zh-CN' }} />
    </div>
  );
}

export default App;
