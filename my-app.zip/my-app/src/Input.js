import logo from './logo.svg';
import './Input.css';

function Input() {
  return (
    <div className="Input">
      <input type="text"></input>
    </div>
  );
}

export default Input;
